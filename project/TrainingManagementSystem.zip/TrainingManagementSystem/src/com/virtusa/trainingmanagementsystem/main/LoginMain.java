package com.virtusa.trainingmanagementsystem.main;

import java.util.Scanner;

import com.virtusa.trainingmanagementsystem.dao.LoginDao;
import com.virtusa.trainingmanagementsystem.model.Login;
import com.virtusa.trainingmanagementsystem.service.LoginVerification;

public class LoginMain {
	public static void main(String[]args) {
		LoginDao existData=new LoginDao();
		int i=0;
		while(i<3){
			System.out.println("number of visiter: "+(i+1));
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ussername");
		String username=sc.nextLine();
		System.out.println("Enter password");
		String password=sc.nextLine();
		System.out.println("Enter designation");
		String designation=sc.nextLine();
		Login enterData=new Login();
		enterData.setUsername(username);;
		enterData.setPassword(password);
		enterData.setDesignation(designation);
		new LoginVerification().verification(enterData,existData);
		i++;
		}
	
	}
	}

