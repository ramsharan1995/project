package com.virtusa.trainingmanagementsystem.dao;

import java.util.HashSet;

public class FeedbackDao {
public static HashSet< String> feedback= new HashSet<String>();
public FeedbackDao() {
	// TODO Auto-generated constructor stub
	feedback.add("trianing is good");
	feedback.add("avg training");
	feedback.add("content  is good");
	feedback.add("trainer is teaching good");
}
}
