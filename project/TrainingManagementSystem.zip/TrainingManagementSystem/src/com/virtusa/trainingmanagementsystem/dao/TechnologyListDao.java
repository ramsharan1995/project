package com.virtusa.trainingmanagementsystem.dao;

import java.util.Vector;

public class TechnologyListDao {
	public static Vector<String> techList=new Vector<String>();
	 public TechnologyListDao()
	{
		techList.add("java");
		techList.add("python");
		techList.add("c++");
		techList.add("Angular");
	}
	
			
}
