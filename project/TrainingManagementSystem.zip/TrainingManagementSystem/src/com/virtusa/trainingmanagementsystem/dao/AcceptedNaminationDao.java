package com.virtusa.trainingmanagementsystem.dao;

import java.util.Vector;

import com.virtusa.trainingmanagementsystem.model.RequestNomination;

public class AcceptedNaminationDao {
public static Vector< RequestNomination> acceptnaminationdao =new Vector<RequestNomination>();
void addNomination(RequestNomination r) {
	acceptnaminationdao.add(r);
	 	
}
	
}
