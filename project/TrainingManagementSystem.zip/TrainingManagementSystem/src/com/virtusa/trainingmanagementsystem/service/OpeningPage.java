package com.virtusa.trainingmanagementsystem.service;

import java.util.Scanner;

public class OpeningPage extends ImplementTrainingOperation {
	@SuppressWarnings("resource")
	void openPage(String designation,String userName)
	{
		switch(designation)
		{
		case "Trainee":{
			System.out.println("Welcome Trainee  "+userName);
			int i=1,choseOperation;
			Scanner sc =new Scanner(System.in);
			while(i==1)
			{
				System.out.println("--------------------you can perform following operation------------------");
				System.out.println("-------------------------------------------------------------------------------");
				System.out.println("1>Nomination     2>Cancel Nomination     3> Veiw  Attending History   4> GiveFeedback      5>View Feedback");
				System.out.println("-------------------------------------------------------------------------------");
				System.out.println("Enter operation index value 1, 2, 3 , 4,5 for respective operation");
				choseOperation=sc.nextInt();
				sc.nextLine();
				switch(choseOperation)
				{
				case 1:
					nomination(userName);
					break;
				case 2:
					cancelNomination(userName);
					break;
				case 3:  
				     attendingHistory();
				     break;
				case 4:
					giveFeedback();
					break;
				case 5:
					viewFeedback();
					break;
				default:
					System.out.println("please enter above respective value");
					
				}	
				System.out.println("\n"+"-------: if you want to perform other operation press 1 : if you want to logout press 2-------------"+"\n");
				 i=sc.nextInt();
				
				
				}
			System.out.println("Logout successful");}
			break;
			
		case "Manager":
		{    
			
			System.out.println("Welcome Manager  "+userName);
			new  ImplimentManagerOperation().approveOrCancelRequest();
			break;
			}
		case "Admin":
		{
			System.out.println("Welcome Admin   "+userName);
			break;	
		}
	   default:
	   {
		   System.out.println("Welcome Trainer"+userName);
		   
		   
		}
	}

}
}
