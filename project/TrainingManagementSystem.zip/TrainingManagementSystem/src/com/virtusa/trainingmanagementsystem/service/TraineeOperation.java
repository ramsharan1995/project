package com.virtusa.trainingmanagementsystem.service;

public interface TraineeOperation {
	void nomination(String userName);
	void cancelNomination(String userName);
	void attendingHistory();


}
