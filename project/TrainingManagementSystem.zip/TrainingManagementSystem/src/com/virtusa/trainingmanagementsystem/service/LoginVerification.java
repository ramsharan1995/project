package com.virtusa.trainingmanagementsystem.service;
import java.util.Map.Entry;

import com.virtusa.trainingmanagementsystem.dao.LoginDao;
import com.virtusa.trainingmanagementsystem.model.Login;

public class LoginVerification {
	public void  verification(Login enterData,LoginDao saveData)
	{
		int i=0;
		for (Entry<String, Login> data : LoginDao.logData.entrySet()) {
		    if(data.getKey().equals(enterData.username) && data.getValue().password.equals(enterData.password)&&data.getValue().designation.equals(enterData.designation)) {
		    //System.out.println(enterData.username+" "+data.getKey());
		    	new OpeningPage().openPage(enterData.designation,enterData.username);
		    	i=1;
		    	}
		   
		    
		}
	     if(i==0)
		   	System.out.println("please Enter correct Data");
		   
	}

}
