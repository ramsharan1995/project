package com.virtusa.trainingmanagementsystem.service;

import java.util.Scanner;
import java.util.Map.Entry;

import com.virtusa.trainingmanagementsystem.dao.FeedbackDao;
import com.virtusa.trainingmanagementsystem.dao.RequestNominationDao;
import com.virtusa.trainingmanagementsystem.dao.TechnologyListDao;
import com.virtusa.trainingmanagementsystem.model.RequestNomination;

public class ImplementTrainingOperation  implements TraineeOperation,Feedback{

	
	private Scanner sc;


	public void cancelNomination(String userName) {
		
	int i=0;
		for (Entry<String, RequestNomination> data : RequestNominationDao.reqNomination.entrySet()) {
		    if(data.getKey().equals(userName) )
		    {
		    	i=1;
		    }
		}
		if(i==1)
		{
			RequestNominationDao.reqNomination.remove(userName);
			System.out.println("your nomination has canceled");
			
		}
		else
		{
			System.out.println("Please enroll or nominate first");
		}
		
		
	}

	
	public void attendingHistory() {
		System.out.println(" nomination history");
		
		
	}


	@Override
	public void nomination(String userName) {
	
		System.out.println("chose Technology");
		new TechnologyListDao();
		for(String s:TechnologyListDao.techList)
			System.out.println(s);
		sc = new Scanner(System.in);
		RequestNomination nomination=new RequestNomination();
		System.out.println("Enter Technology");
		nomination.setTechnology(sc.nextLine());
     	System.out.println("Enter Employee Name");
		nomination.setEmp_name(sc.nextLine());
		System.out.println("Enter Employee Email");
		nomination.setEmp_email(sc.nextLine());
		System.out.println("Enter Employee id");
		nomination.setEmp_id(sc.nextInt());
		
		
		new RequestNominationDao().request(userName,nomination);
		System.out.println("your request sended");
		
	}


	@Override
	public void giveFeedback() {
		// TODO Auto-generated method stub
		
		System.out.println("give feedback......");
		new FeedbackDao();
		sc = new Scanner(System.in);
		String feedback1=sc.nextLine();
	  FeedbackDao.feedback.add(feedback1);
		System.out.println("Thanks for giving feedback");
	}


	@Override
	public void viewFeedback() {
		// TODO Auto-generated method stub
		for(String s1:FeedbackDao.feedback) {
			System.out.println(s1);
		}
	}}


	



