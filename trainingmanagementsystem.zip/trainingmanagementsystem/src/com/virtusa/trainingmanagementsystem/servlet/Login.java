package com.virtusa.trainingmanagementsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.trainingmanagementsystem.dao.Conection;
import com.virtusa.trainingmanagementsystem.service.LoginVerification;

public class Login extends HttpServlet {
	public static Connection con = null;
	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException {
		con = Conection.createConection();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter pw = response.getWriter();

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		pw.print("username " + username + " pass" + password);
		String designation = new LoginVerification().verification(username, password);
		if (designation.equals("not")) {
//    			 RequestDispatcher dis=request.getRequestDispatcher("login.html");
//    					 dis.forward(request, response);
			pw.print("username " + designation);
		}

		switch ("Trainee") {
		case "Trainee":
			request.getRequestDispatcher("otherPage/nav.html").forward(request, response);
			;
			break;
		default:
			pw.append("jsdkjds");
		}

	}
}
