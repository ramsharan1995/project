package com.virtusa.trainingmanagementsystem.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.trainingmanagementsystem.servlet.Login;

public class LoginVerification {
	public String verification(String username, String password) {
		String s = "not";
		Statement st = null;
		try {

			st = Login.con.createStatement();
			ResultSet data = st.executeQuery("select designation from LoginDao where userName='" + username
					+ "' and password='" + password + "'");
			data.next();
			s = data.getString(3);
		} catch (SQLException e1) {

		}
		return s;

	}
}
